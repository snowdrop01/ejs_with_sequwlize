const User = require('../models/user');
const Sequelize = require('sequelize');

const createUser = async (req, res) => {
    
       
}


module.exports = {
    createUser
}