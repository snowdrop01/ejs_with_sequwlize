const express = require('express');
const sequelize = require('./database');

const app = express();

const bodyParser = require("body-parser");

const path = require("path");


app.set('view engine','ejs')

var data = [];

var del = [];

var update = [];

app.use(bodyParser.urlencoded({extended:true}))

app.use(express.static(path.join(__dirname,"public")))

var email;


app.get('/index',(req,res,next)=>{
    res.sendFile(path.join(__dirname,"views","index.html"))
})

app.post('/',(req,res,next)=>{
    // console.log(req.body);
    data.push(req.body);
    res.render('index',{data : data});
    // console.log(data)
})
app.get('/',(req,res,next)=>{
    res.render('index',{data : data});
    // console.log(data)
})

app.post('/delete',(req,res,next)=>{
    del = req.body
    var index = Number(del.deleted);
    data.splice(index,1);
    res.redirect('/');
})

app.post('/update',(req,res,next)=>{
    update = req.body.update
    var index = Number(update)
    res.render('update',{data : data[index], index : index})
    data.splice(index,1)
})

app.post('/updateData',(req,res,next)=>{
    var updateData = req.body;
    var index = Number(req.body.index);
    // console.log(index);
    data.splice(index,0,updateData);
    res.redirect('/');
})

const userRouter = require('./routes/user.route')
app.use('/',userRouter)

sequelize.sync().then(result =>{
   // console.log(result);
    app.listen(4050);
})
.catch(err=> {

});
