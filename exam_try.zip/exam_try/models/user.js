const Sequelize = require('sequelize');
const sequelize = require('../database');

const User = sequelize.define('user',{
    userid: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
      },
      fullName: {
        type: Sequelize.STRING,
        allowNull: false,
        require:true
      },

      lastName: {
        type: Sequelize.STRING,
        allowNull: false,
        require:true
      },

      email: {
        type: Sequelize.STRING,
        allowNull: false,
        require: true
      },
     
      dateOfBirth: {
        type: Sequelize.DATE,
        allowNull: false,
        require: true
      },

      phoneNumber: {
        type: Sequelize.BIGINT,
        allowNull: false,
        require: true
      }
     
    });


    module.exports = User;